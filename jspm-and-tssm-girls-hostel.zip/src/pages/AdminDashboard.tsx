import React, { useEffect, useState } from 'react';
import { collection, query, onSnapshot, doc, updateDoc, orderBy } from 'firebase/firestore';
import { db, auth } from '../lib/firebase';
import { useAuth } from '../context/AuthContext';
import { PassRequest, StudentData, Complaint, UserProfile } from '../types';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../components/ui/table';
import { toast } from 'sonner';
import { LogOut, Users, FileCheck, AlertCircle, LayoutDashboard } from 'lucide-react';
import { signOut } from 'firebase/auth';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

export const AdminDashboard: React.FC = () => {
  const { profile } = useAuth();
  const [students, setStudents] = useState<(StudentData & { name: string })[]>([]);
  const [passes, setPasses] = useState<PassRequest[]>([]);
  const [complaints, setComplaints] = useState<Complaint[]>([]);
  const [users, setUsers] = useState<UserProfile[]>([]);

  useEffect(() => {
    // Listen to all users to get names
    const unsubUsers = onSnapshot(collection(db, 'users'), (snapshot) => {
      setUsers(snapshot.docs.map(doc => doc.data() as UserProfile));
    });

    // Listen to all students
    const unsubStudents = onSnapshot(collection(db, 'students'), (snapshot) => {
      const studentList = snapshot.docs.map(doc => doc.data() as StudentData);
      setStudents(studentList.map(s => ({
        ...s,
        name: users.find(u => u.uid === s.uid)?.name || 'Unknown'
      })));
    });

    // Listen to all passes
    const unsubPasses = onSnapshot(query(collection(db, 'passes'), orderBy('createdAt', 'desc')), (snapshot) => {
      setPasses(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as PassRequest)));
    });

    // Listen to all complaints
    const unsubComplaints = onSnapshot(query(collection(db, 'complaints'), orderBy('createdAt', 'desc')), (snapshot) => {
      setComplaints(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Complaint)));
    });

    return () => {
      unsubUsers();
      unsubStudents();
      unsubPasses();
      unsubComplaints();
    };
  }, [users.length]);

  const handleApprovePass = async (passId: string) => {
    try {
      await updateDoc(doc(db, 'passes', passId), {
        adminApproval: 'approved',
        status: 'approved'
      });
      toast.success('Pass approved');
    } catch (error: any) {
      toast.error(error.message);
    }
  };

  const handleResolveComplaint = async (complaintId: string) => {
    try {
      await updateDoc(doc(db, 'complaints', complaintId), {
        status: 'resolved'
      });
      toast.success('Complaint resolved');
    } catch (error: any) {
      toast.error(error.message);
    }
  };

  const stats = [
    { name: 'IN', value: students.filter(s => s.currentStatus === 'IN').length },
    { name: 'OUT', value: students.filter(s => s.currentStatus === 'OUT').length },
    { name: 'LATE', value: students.filter(s => s.currentStatus === 'LATE').length },
  ];

  return (
    <div className="min-h-screen bg-slate-50">
      <header className="bg-white border-b p-4 sticky top-0 z-10 flex justify-between items-center">
        <div className="flex items-center gap-2">
          <LayoutDashboard className="h-6 w-6 text-primary" />
          <h1 className="text-xl font-bold text-primary">JSPM & TSSM Admin</h1>
        </div>
        <Button variant="ghost" size="icon" onClick={() => signOut(auth)}>
          <LogOut className="h-5 w-5" />
        </Button>
      </header>

      <main className="p-6 space-y-6 max-w-7xl mx-auto">
        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total Students</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold">{students.length}</p>
            </CardContent>
          </Card>
          <Card className="md:col-span-2">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Hostel Occupancy</CardTitle>
            </CardHeader>
            <CardContent className="h-[100px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={stats} layout="vertical">
                  <XAxis type="number" hide />
                  <YAxis dataKey="name" type="category" width={50} />
                  <Tooltip />
                  <Bar dataKey="value" fill="hsl(var(--primary))" radius={[0, 4, 4, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="status" className="w-full">
          <TabsList>
            <TabsTrigger value="status">Live Status</TabsTrigger>
            <TabsTrigger value="passes">Pass Requests</TabsTrigger>
            <TabsTrigger value="complaints">Complaints</TabsTrigger>
          </TabsList>

          <TabsContent value="status" className="pt-4">
            <Card>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Student Name</TableHead>
                    <TableHead>Room</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Last Exit</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {students.map(student => (
                    <TableRow key={student.uid}>
                      <TableCell className="font-medium">{student.name}</TableCell>
                      <TableCell>{student.roomNo}</TableCell>
                      <TableCell>
                        <Badge variant={student.currentStatus === 'IN' ? 'default' : student.currentStatus === 'OUT' ? 'secondary' : 'destructive'}>
                          {student.currentStatus}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-xs text-muted-foreground">
                        {student.lastExitTime ? new Date(student.lastExitTime).toLocaleString() : 'N/A'}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </Card>
          </TabsContent>

          <TabsContent value="passes" className="pt-4">
            <div className="grid gap-4">
              {passes.filter(p => p.status === 'pending').map(pass => (
                <Card key={pass.id}>
                  <CardContent className="p-4 flex justify-between items-center">
                    <div>
                      <div className="flex items-center gap-2">
                        <p className="font-bold">{pass.studentName}</p>
                        <Badge variant="outline" className="capitalize">{pass.type}</Badge>
                      </div>
                      <p className="text-sm text-muted-foreground">{pass.reason}</p>
                      <p className="text-xs text-muted-foreground mt-1">
                        Expected Return: {new Date(pass.expectedReturnTime).toLocaleString()}
                      </p>
                    </div>
                    <div className="flex gap-2">
                      <Button size="sm" onClick={() => handleApprovePass(pass.id)}>Approve</Button>
                      <Button size="sm" variant="destructive">Reject</Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
              {passes.filter(p => p.status === 'pending').length === 0 && (
                <p className="text-center text-muted-foreground py-8">No pending pass requests.</p>
              )}
            </div>
          </TabsContent>

          <TabsContent value="complaints" className="pt-4">
            <div className="grid gap-4">
              {complaints.filter(c => c.status === 'pending').map(complaint => (
                <Card key={complaint.id}>
                  <CardContent className="p-4 flex justify-between items-center">
                    <div>
                      <p className="font-bold">{complaint.studentName}</p>
                      <p className="text-sm">{complaint.issue}</p>
                      <p className="text-xs text-muted-foreground mt-1">{new Date(complaint.createdAt).toLocaleString()}</p>
                    </div>
                    <Button size="sm" variant="outline" onClick={() => handleResolveComplaint(complaint.id)}>Mark Resolved</Button>
                  </CardContent>
                </Card>
              ))}
              {complaints.filter(c => c.status === 'pending').length === 0 && (
                <p className="text-center text-muted-foreground py-8">No pending complaints.</p>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
};
