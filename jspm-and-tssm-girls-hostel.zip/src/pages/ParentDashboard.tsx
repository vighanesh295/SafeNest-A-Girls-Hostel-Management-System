import React, { useEffect, useState } from 'react';
import { collection, query, where, onSnapshot, doc, updateDoc, orderBy } from 'firebase/firestore';
import { db, auth } from '../lib/firebase';
import { useAuth } from '../context/AuthContext';
import { PassRequest, StudentData, UserProfile } from '../types';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { toast } from 'sonner';
import { LogOut, Heart, ShieldCheck, Clock, MapPin, Home, History, User as UserIcon } from 'lucide-react';
import { signOut } from 'firebase/auth';

export const ParentDashboard: React.FC = () => {
  const { profile } = useAuth();
  const [daughter, setDaughter] = useState<StudentData | null>(null);
  const [daughterProfile, setDaughterProfile] = useState<UserProfile | null>(null);
  const [passes, setPasses] = useState<PassRequest[]>([]);
  const [activeTab, setActiveTab] = useState<'home' | 'history' | 'profile'>('home');

  useEffect(() => {
    if (!profile) return;

    // In this demo, we'll find the first student that has this parent's ID
    // In a real app, this would be a direct link
    const qStudent = query(collection(db, 'students'), where('parentId', '==', profile.uid));
    const unsubStudent = onSnapshot(qStudent, (snapshot) => {
      if (!snapshot.empty) {
        const sData = snapshot.docs[0].data() as StudentData;
        setDaughter(sData);
        
        // Get daughter's profile name
        onSnapshot(doc(db, 'users', sData.uid), (dDoc) => {
          if (dDoc.exists()) setDaughterProfile(dDoc.data() as UserProfile);
        });

        // Get daughter's passes
        const qPasses = query(collection(db, 'passes'), where('studentId', '==', sData.uid), orderBy('createdAt', 'desc'));
        onSnapshot(qPasses, (pSnapshot) => {
          setPasses(pSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as PassRequest)));
        });
      }
    });

    return () => unsubStudent();
  }, [profile]);

  const handleApprovePass = async (passId: string) => {
    try {
      await updateDoc(doc(db, 'passes', passId), {
        parentApproval: 'approved'
      });
      toast.success('Pass approved by you');
    } catch (error: any) {
      toast.error(error.message);
    }
  };

  if (!daughter) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-4 text-center bg-slate-50 max-w-md mx-auto border-x">
        <ShieldCheck className="h-16 w-16 text-muted-foreground mb-4" />
        <h2 className="text-xl font-bold">No student linked to this account</h2>
        <p className="text-muted-foreground max-w-xs mt-2">Please contact the hostel admin to link your daughter's account to your profile.</p>
        <Button variant="ghost" className="mt-8" onClick={() => signOut(auth)}>Logout</Button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col max-w-md mx-auto border-x shadow-xl">
      <header className="bg-white p-6 flex justify-between items-center border-b rounded-b-3xl shadow-sm">
        <div className="flex items-center gap-2">
          <Heart className="h-6 w-6 text-rose-500 fill-rose-500" />
          <h1 className="text-2xl font-bold text-primary">JSPM & TSSM</h1>
        </div>
        <Badge variant="outline">Parent</Badge>
      </header>

      <main className="flex-1 overflow-y-auto p-6 space-y-6 pb-24">
        {activeTab === 'home' && (
          <>
            <Card className="border-none shadow-lg bg-white rounded-3xl overflow-hidden">
              <CardHeader className="pb-2">
                <CardTitle className="text-xl">{daughterProfile?.name}'s Status</CardTitle>
                <CardDescription>Real-time location and safety status</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between p-4 bg-slate-50 rounded-xl">
                  <div className="flex items-center gap-3">
                    <MapPin className="h-5 w-5 text-primary" />
                    <span className="font-medium">Current Location</span>
                  </div>
                  <Badge variant={daughter.currentStatus === 'IN' ? 'default' : daughter.currentStatus === 'OUT' ? 'secondary' : 'destructive'} className="px-4">
                    {daughter.currentStatus === 'IN' ? 'Inside Hostel' : daughter.currentStatus === 'OUT' ? 'Outside' : 'LATE'}
                  </Badge>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="p-4 bg-slate-50 rounded-xl space-y-1">
                    <p className="text-xs text-muted-foreground">Last Entry</p>
                    <p className="text-sm font-bold">{daughter.lastEntryTime ? new Date(daughter.lastEntryTime).toLocaleTimeString() : 'N/A'}</p>
                  </div>
                  <div className="p-4 bg-slate-50 rounded-xl space-y-1">
                    <p className="text-xs text-muted-foreground">Last Exit</p>
                    <p className="text-sm font-bold">{daughter.lastExitTime ? new Date(daughter.lastExitTime).toLocaleTimeString() : 'N/A'}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="space-y-4">
              <h3 className="font-bold text-lg flex items-center gap-2">
                <Clock className="h-5 w-5" />
                Pending Approvals
              </h3>
              
              {passes.filter(p => p.type === 'nightout' && p.parentApproval === 'pending').map(pass => (
                <Card key={pass.id} className="border-rose-100 bg-rose-50/30 shadow-sm rounded-2xl">
                  <CardContent className="p-4 space-y-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <Badge variant="destructive" className="mb-2">Action Required</Badge>
                        <p className="font-bold">Night Out Request</p>
                        <p className="text-sm text-muted-foreground">{pass.reason}</p>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button className="flex-1 h-10" onClick={() => handleApprovePass(pass.id)}>Approve</Button>
                      <Button variant="outline" className="flex-1 h-10">Reject</Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
              {passes.filter(p => p.type === 'nightout' && p.parentApproval === 'pending').length === 0 && (
                <p className="text-sm text-muted-foreground text-center py-4 bg-white rounded-2xl shadow-sm">No pending requests</p>
              )}
            </div>
          </>
        )}

        {activeTab === 'history' && (
          <div className="space-y-4">
            <h3 className="font-bold text-xl">Daughter's Outings</h3>
            {passes.map(pass => (
              <Card key={pass.id} className="border-none shadow-sm rounded-2xl">
                <CardContent className="p-4 flex justify-between items-center">
                  <div>
                    <div className="flex items-center gap-2">
                      <p className="font-bold capitalize">{pass.type} Pass</p>
                      <Badge variant="outline">{pass.status}</Badge>
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">
                      {new Date(pass.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-[10px] font-medium">Admin: {pass.adminApproval}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {activeTab === 'profile' && (
          <div className="space-y-6 text-center py-10">
            <div className="w-24 h-24 bg-rose-50 rounded-full mx-auto flex items-center justify-center">
              <UserIcon className="h-12 w-12 text-rose-500" />
            </div>
            <div>
              <h3 className="text-2xl font-bold">{profile?.name}</h3>
              <p className="text-muted-foreground">Parent Account</p>
            </div>
            <Button variant="destructive" onClick={() => signOut(auth)} className="w-full">Logout</Button>
          </div>
        )}
      </main>

      <nav className="fixed bottom-0 left-0 right-0 max-w-md mx-auto bg-white border-t px-6 py-3 flex justify-between items-center rounded-t-3xl shadow-[0_-4px_10px_rgba(0,0,0,0.05)]">
        <button onClick={() => setActiveTab('home')} className={`flex flex-col items-center gap-1 ${activeTab === 'home' ? 'text-primary' : 'text-slate-400'}`}>
          <Home className="h-6 w-6" />
          <span className="text-[10px] font-bold">Home</span>
        </button>
        <button onClick={() => setActiveTab('history')} className={`flex flex-col items-center gap-1 ${activeTab === 'history' ? 'text-primary' : 'text-slate-400'}`}>
          <History className="h-6 w-6" />
          <span className="text-[10px] font-bold">History</span>
        </button>
        <button onClick={() => setActiveTab('profile')} className={`flex flex-col items-center gap-1 ${activeTab === 'profile' ? 'text-primary' : 'text-slate-400'}`}>
          <UserIcon className="h-6 w-6" />
          <span className="text-[10px] font-bold">Profile</span>
        </button>
      </nav>
    </div>
  );
};
