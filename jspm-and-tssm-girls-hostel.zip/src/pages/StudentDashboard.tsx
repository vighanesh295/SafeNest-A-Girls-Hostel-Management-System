import React, { useEffect, useState } from 'react';
import { collection, query, where, onSnapshot, addDoc, doc, updateDoc, getDocs, orderBy } from 'firebase/firestore';
import { db, auth } from '../lib/firebase';
import { useAuth } from '../context/AuthContext';
import { PassRequest, StudentData, Complaint } from '../types';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '../components/ui/dialog';
import { toast } from 'sonner';
import { LogOut, Clock, AlertCircle, Home, History, User as UserIcon, Plus } from 'lucide-react';
import { signOut } from 'firebase/auth';

export const StudentDashboard: React.FC = () => {
  const { profile } = useAuth();
  const [studentData, setStudentData] = useState<StudentData | null>(null);
  const [passes, setPasses] = useState<PassRequest[]>([]);
  const [complaints, setComplaints] = useState<Complaint[]>([]);
  const [activeTab, setActiveTab] = useState<'home' | 'history' | 'profile'>('home');
  
  const [isPassDialogOpen, setIsPassDialogOpen] = useState(false);
  const [isComplaintDialogOpen, setIsComplaintDialogOpen] = useState(false);
  const [passType, setPassType] = useState<'lunch' | 'late' | 'nightout'>('lunch');
  const [passReason, setPassReason] = useState('');
  const [complaintIssue, setComplaintIssue] = useState('');

  useEffect(() => {
    if (!profile) return;
    const unsubStudent = onSnapshot(doc(db, 'students', profile.uid), (doc) => {
      if (doc.exists()) setStudentData(doc.data() as StudentData);
    });
    const qPasses = query(collection(db, 'passes'), where('studentId', '==', profile.uid), orderBy('createdAt', 'desc'));
    const unsubPasses = onSnapshot(qPasses, (snapshot) => {
      setPasses(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as PassRequest)));
    });
    const qComplaints = query(collection(db, 'complaints'), where('studentId', '==', profile.uid), orderBy('createdAt', 'desc'));
    const unsubComplaints = onSnapshot(qComplaints, (snapshot) => {
      setComplaints(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Complaint)));
    });
    return () => { unsubStudent(); unsubPasses(); unsubComplaints(); };
  }, [profile]);

  const handleApplyPass = async () => {
    if (!profile) return;
    try {
      const now = new Date();
      let expectedReturn = new Date();
      if (passType === 'lunch') expectedReturn.setHours(now.getHours() + 1);
      else if (passType === 'late') expectedReturn.setHours(21, 0, 0);
      else expectedReturn.setDate(now.getDate() + 1);

      await addDoc(collection(db, 'passes'), {
        studentId: profile.uid,
        studentName: profile.name,
        type: passType,
        reason: passReason,
        outTime: now.toISOString(),
        expectedReturnTime: expectedReturn.toISOString(),
        parentApproval: passType === 'nightout' ? 'pending' : 'approved',
        adminApproval: 'pending',
        status: 'pending',
        createdAt: now.toISOString()
      });
      toast.success('Pass request submitted');
      setIsPassDialogOpen(false);
      setPassReason('');
    } catch (error: any) { toast.error(error.message); }
  };

  const handleMockExit = async (pass: PassRequest) => {
    if (!profile || !studentData) return;
    try {
      await updateDoc(doc(db, 'passes', pass.id), { status: 'active', exitTime: new Date().toISOString() });
      await updateDoc(doc(db, 'students', profile.uid), { currentStatus: 'OUT', lastExitTime: new Date().toISOString(), activePassId: pass.id });
      toast.success('Exited successfully');
    } catch (error: any) { toast.error(error.message); }
  };

  const handleMockEntry = async () => {
    if (!profile || !studentData || !studentData.activePassId) return;
    try {
      const now = new Date();
      const passRef = doc(db, 'passes', studentData.activePassId);
      const passSnap = await getDocs(query(collection(db, 'passes'), where('__name__', '==', studentData.activePassId)));
      const passData = passSnap.docs[0].data() as PassRequest;
      const isLate = now > new Date(passData.expectedReturnTime);
      await updateDoc(passRef, { status: isLate ? 'violated' : 'completed', actualReturnTime: now.toISOString() });
      await updateDoc(doc(db, 'students', profile.uid), { currentStatus: 'IN', lastEntryTime: now.toISOString(), activePassId: null });
      toast.success(isLate ? 'Returned LATE' : 'Returned successfully');
    } catch (error: any) { toast.error(error.message); }
  };

  const handleReportComplaint = async () => {
    if (!profile) return;
    try {
      await addDoc(collection(db, 'complaints'), {
        studentId: profile.uid,
        studentName: profile.name,
        issue: complaintIssue,
        category: 'general',
        status: 'pending',
        createdAt: new Date().toISOString()
      });
      toast.success('Complaint reported');
      setIsComplaintDialogOpen(false);
      setComplaintIssue('');
    } catch (error: any) { toast.error(error.message); }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col max-w-md mx-auto border-x shadow-xl">
      {/* App Header */}
      <header className="bg-white p-6 flex justify-between items-center border-b rounded-b-3xl shadow-sm">
        <div>
          <h1 className="text-2xl font-bold text-primary">JSPM & TSSM</h1>
          <p className="text-sm text-muted-foreground">Hi, {profile?.name.split(' ')[0]}</p>
        </div>
        <div className="flex gap-2">
          <Badge variant={studentData?.currentStatus === 'IN' ? 'default' : 'destructive'} className="h-6">
            {studentData?.currentStatus || 'IN'}
          </Badge>
        </div>
      </header>

      <main className="flex-1 overflow-y-auto p-6 space-y-6 pb-24">
        {activeTab === 'home' && (
          <>
            {/* Status Card */}
            <Card className="bg-primary text-primary-foreground border-none shadow-lg overflow-hidden relative">
              <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -mr-16 -mt-16 blur-2xl" />
              <CardContent className="p-6 relative z-10">
                <p className="text-primary-foreground/80 text-sm mb-1">Current Status</p>
                <h2 className="text-3xl font-bold mb-4">{studentData?.currentStatus === 'IN' ? 'Inside Hostel' : 'Outside'}</h2>
                <div className="flex justify-between items-end">
                  <div>
                    <p className="text-primary-foreground/60 text-xs uppercase tracking-wider">Room No</p>
                    <p className="text-xl font-semibold">{studentData?.roomNo || '101'}</p>
                  </div>
                  {studentData?.currentStatus === 'OUT' && (
                    <Button variant="secondary" onClick={handleMockEntry} className="font-bold">Mark Entry</Button>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <div className="grid grid-cols-2 gap-4">
              <Dialog open={isPassDialogOpen} onOpenChange={setIsPassDialogOpen}>
                <DialogTrigger asChild>
                  <Button className="h-32 flex-col gap-3 bg-white text-slate-900 hover:bg-slate-50 border-none shadow-md" variant="outline">
                    <div className="p-3 bg-blue-50 rounded-2xl">
                      <Clock className="h-6 w-6 text-blue-600" />
                    </div>
                    <span className="font-semibold">Apply Pass</span>
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[425px] rounded-t-3xl sm:rounded-lg bottom-0 top-auto translate-y-0 sm:top-1/2 sm:-translate-y-1/2">
                  <DialogHeader>
                    <DialogTitle>New Outing Pass</DialogTitle>
                    <DialogDescription>Select the type of pass you need.</DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4 py-4">
                    <div className="space-y-2">
                      <Label>Type</Label>
                      <Select value={passType} onValueChange={(v: any) => setPassType(v)}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="lunch">Lunch Pass (1 hr)</SelectItem>
                          <SelectItem value="late">Late Pass (Until 9 PM)</SelectItem>
                          <SelectItem value="nightout">Night Out (Home)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label>Reason</Label>
                      <Input placeholder="E.g. Library, Shopping" value={passReason} onChange={(e) => setPassReason(e.target.value)} />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button onClick={handleApplyPass} className="w-full h-12 rounded-xl">Submit Request</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>

              <Dialog open={isComplaintDialogOpen} onOpenChange={setIsComplaintDialogOpen}>
                <DialogTrigger asChild>
                  <Button className="h-32 flex-col gap-3 bg-white text-slate-900 hover:bg-slate-50 border-none shadow-md" variant="outline">
                    <div className="p-3 bg-rose-50 rounded-2xl">
                      <AlertCircle className="h-6 w-6 text-rose-600" />
                    </div>
                    <span className="font-semibold">Report Issue</span>
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[425px] rounded-t-3xl sm:rounded-lg bottom-0 top-auto translate-y-0 sm:top-1/2 sm:-translate-y-1/2">
                  <DialogHeader>
                    <DialogTitle>Report Complaint</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4 py-4">
                    <Input placeholder="Describe the issue..." value={complaintIssue} onChange={(e) => setComplaintIssue(e.target.value)} />
                  </div>
                  <DialogFooter>
                    <Button onClick={handleReportComplaint} className="w-full h-12 rounded-xl">Submit</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>

            {/* Active Pass Section */}
            <div className="space-y-3">
              <h3 className="font-bold text-lg">Active Pass</h3>
              {passes.find(p => p.status === 'approved' || p.status === 'active') ? (
                passes.filter(p => p.status === 'approved' || p.status === 'active').map(pass => (
                  <Card key={pass.id} className="border-none shadow-md">
                    <CardContent className="p-4 flex justify-between items-center">
                      <div>
                        <p className="font-bold capitalize">{pass.type} Pass</p>
                        <p className="text-xs text-muted-foreground">Exp. Return: {new Date(pass.expectedReturnTime).toLocaleTimeString()}</p>
                      </div>
                      {pass.status === 'approved' && <Button size="sm" onClick={() => handleMockExit(pass)}>Exit Now</Button>}
                      {pass.status === 'active' && <Badge>OUTSIDE</Badge>}
                    </CardContent>
                  </Card>
                ))
              ) : (
                <p className="text-sm text-muted-foreground bg-white p-4 rounded-2xl text-center shadow-sm">No active passes</p>
              )}
            </div>
          </>
        )}

        {activeTab === 'history' && (
          <div className="space-y-4">
            <h3 className="font-bold text-xl">Pass History</h3>
            {passes.map(pass => (
              <Card key={pass.id} className="border-none shadow-sm">
                <CardContent className="p-4 flex justify-between items-center">
                  <div>
                    <p className="font-semibold capitalize">{pass.type}</p>
                    <p className="text-xs text-muted-foreground">{new Date(pass.createdAt).toLocaleDateString()}</p>
                  </div>
                  <Badge variant={pass.status === 'completed' ? 'outline' : pass.status === 'violated' ? 'destructive' : 'secondary'}>
                    {pass.status}
                  </Badge>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {activeTab === 'profile' && (
          <div className="space-y-6 text-center py-10">
            <div className="w-24 h-24 bg-primary/10 rounded-full mx-auto flex items-center justify-center">
              <UserIcon className="h-12 w-12 text-primary" />
            </div>
            <div>
              <h3 className="text-2xl font-bold">{profile?.name}</h3>
              <p className="text-muted-foreground">{profile?.email}</p>
            </div>
            <Button variant="destructive" onClick={() => signOut(auth)} className="w-full">Logout</Button>
          </div>
        )}
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 max-w-md mx-auto bg-white border-t px-6 py-3 flex justify-between items-center rounded-t-3xl shadow-[0_-4px_10px_rgba(0,0,0,0.05)]">
        <button onClick={() => setActiveTab('home')} className={`flex flex-col items-center gap-1 ${activeTab === 'home' ? 'text-primary' : 'text-slate-400'}`}>
          <Home className="h-6 w-6" />
          <span className="text-[10px] font-bold">Home</span>
        </button>
        <button onClick={() => setActiveTab('history')} className={`flex flex-col items-center gap-1 ${activeTab === 'history' ? 'text-primary' : 'text-slate-400'}`}>
          <History className="h-6 w-6" />
          <span className="text-[10px] font-bold">History</span>
        </button>
        <button onClick={() => setActiveTab('profile')} className={`flex flex-col items-center gap-1 ${activeTab === 'profile' ? 'text-primary' : 'text-slate-400'}`}>
          <UserIcon className="h-6 w-6" />
          <span className="text-[10px] font-bold">Profile</span>
        </button>
      </nav>
    </div>
  );
};
