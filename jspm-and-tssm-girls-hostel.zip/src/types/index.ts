export type UserRole = 'student' | 'parent' | 'admin';
export type PassType = 'lunch' | 'late' | 'nightout';
export type PassStatus = 'pending' | 'approved' | 'rejected' | 'active' | 'completed' | 'violated';
export type ApprovalStatus = 'pending' | 'approved' | 'rejected';
export type StudentStatus = 'IN' | 'OUT' | 'LATE';

export interface UserProfile {
  uid: string;
  name: string;
  email: string;
  role: UserRole;
  phone?: string;
  createdAt: string;
}

export interface StudentData {
  uid: string;
  parentId: string;
  roomNo: string;
  currentStatus: StudentStatus;
  lastExitTime?: string;
  lastEntryTime?: string;
  activePassId?: string;
}

export interface PassRequest {
  id: string;
  studentId: string;
  studentName?: string;
  type: PassType;
  reason: string;
  outTime: string;
  expectedReturnTime: string;
  actualReturnTime?: string;
  exitTime?: string;
  parentApproval: ApprovalStatus;
  adminApproval: ApprovalStatus;
  status: PassStatus;
  createdAt: string;
}

export interface Complaint {
  id: string;
  studentId: string;
  studentName?: string;
  issue: string;
  category: string;
  status: 'pending' | 'resolved';
  createdAt: string;
}
